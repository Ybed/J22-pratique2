package ma.ens.hopitalpratique2.entities;

public enum StatusRDV {
    PENDING,
    CANCELED,
    DONE
}
